=================================================
 Oranmental Relief Loops 001 NM Ani-01 Dark Gray
 A Plymouth bootsplash
=================================================

Licence rules:
- you can use this as much and as long as you want
- you paid for it but it's not really a commercial product, it's a donationware oss, you can modify
  this like you want for your needs as long as you don't sell it later as yours
- you can share it with family members but please limit further redistribution/reselling, it's not
  expensive to get this
- there are no in-app more features payments, subscription or gimmie money demo mode

Copyright (C) Markospoko
